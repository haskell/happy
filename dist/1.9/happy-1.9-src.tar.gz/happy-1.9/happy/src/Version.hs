module Version (version) where

version = tail "\ 
  \ HAPPY_VERSION"
