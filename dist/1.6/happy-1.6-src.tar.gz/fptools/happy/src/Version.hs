module Version (version) where

version = "1.6"
