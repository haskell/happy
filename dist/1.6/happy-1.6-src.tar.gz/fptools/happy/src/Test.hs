-- parser produced by Happy Version 1.6


import Char
import GlaExts -- for happy -g
import Array   -- for happy -a

data HappyAbsSyn 
	= HappyTerminal Token
	| HappyErrorToken Int
	| HappyAbsSyn4 (Exp)
	| HappyAbsSyn5 (Exp1)
	| HappyAbsSyn6 (Term)
	| HappyAbsSyn7 (Factor)

type HappyReduction = 
	   Int 
	-> (Token)
	-> HappyState (Token) ([HappyAbsSyn] -> [(Token)] -> Exp)
	-> [HappyState (Token) ([HappyAbsSyn] -> [(Token)] -> Exp)] 
	-> [HappyAbsSyn] 
	-> [(Token)] -> Exp

action_0,
 action_1,
 action_2,
 action_3,
 action_4,
 action_5,
 action_6,
 action_7,
 action_8,
 action_9,
 action_10,
 action_11,
 action_12,
 action_13,
 action_14,
 action_15,
 action_16,
 action_17,
 action_18,
 action_19,
 action_20,
 action_21,
 action_22,
 action_23 :: Int -> HappyReduction

happyReduce_1,
 happyReduce_2,
 happyReduce_3,
 happyReduce_4,
 happyReduce_5,
 happyReduce_6,
 happyReduce_7,
 happyReduce_8,
 happyReduce_9,
 happyReduce_10,
 happyReduce_11 :: HappyReduction

action_0 (8) = happyShift action_5
action_0 (10) = happyShift action_6
action_0 (11) = happyShift action_7
action_0 (17) = happyShift action_8
action_0 (4) = happyGoto action_1
action_0 (5) = happyGoto action_2
action_0 (6) = happyGoto action_3
action_0 (7) = happyGoto action_4
action_0 _ = happyFail

action_1 (19) = happyAccept
action_1 _ = happyFail

action_2 (13) = happyShift action_13
action_2 (14) = happyShift action_14
action_2 _ = happyReduce_2

action_3 (15) = happyShift action_11
action_3 (16) = happyShift action_12
action_3 _ = happyReduce_5

action_4 _ = happyReduce_8

action_5 (11) = happyShift action_10
action_5 _ = happyFail

action_6 _ = happyReduce_9

action_7 _ = happyReduce_10

action_8 (8) = happyShift action_5
action_8 (10) = happyShift action_6
action_8 (11) = happyShift action_7
action_8 (17) = happyShift action_8
action_8 (4) = happyGoto action_9
action_8 (5) = happyGoto action_2
action_8 (6) = happyGoto action_3
action_8 (7) = happyGoto action_4
action_8 _ = happyFail

action_9 (18) = happyShift action_20
action_9 _ = happyFail

action_10 (12) = happyShift action_19
action_10 _ = happyFail

action_11 (10) = happyShift action_6
action_11 (11) = happyShift action_7
action_11 (17) = happyShift action_8
action_11 (7) = happyGoto action_18
action_11 _ = happyFail

action_12 (10) = happyShift action_6
action_12 (11) = happyShift action_7
action_12 (17) = happyShift action_8
action_12 (7) = happyGoto action_17
action_12 _ = happyFail

action_13 (10) = happyShift action_6
action_13 (11) = happyShift action_7
action_13 (17) = happyShift action_8
action_13 (6) = happyGoto action_16
action_13 (7) = happyGoto action_4
action_13 _ = happyFail

action_14 (10) = happyShift action_6
action_14 (11) = happyShift action_7
action_14 (17) = happyShift action_8
action_14 (6) = happyGoto action_15
action_14 (7) = happyGoto action_4
action_14 _ = happyFail

action_15 (15) = happyShift action_11
action_15 (16) = happyShift action_12
action_15 _ = happyReduce_4

action_16 (15) = happyShift action_11
action_16 (16) = happyShift action_12
action_16 _ = happyReduce_3

action_17 _ = happyReduce_7

action_18 _ = happyReduce_6

action_19 (8) = happyShift action_5
action_19 (10) = happyShift action_6
action_19 (11) = happyShift action_7
action_19 (17) = happyShift action_8
action_19 (4) = happyGoto action_21
action_19 (5) = happyGoto action_2
action_19 (6) = happyGoto action_3
action_19 (7) = happyGoto action_4
action_19 _ = happyFail

action_20 _ = happyReduce_11

action_21 (9) = happyShift action_22
action_21 _ = happyFail

action_22 (8) = happyShift action_5
action_22 (10) = happyShift action_6
action_22 (11) = happyShift action_7
action_22 (17) = happyShift action_8
action_22 (4) = happyGoto action_23
action_22 (5) = happyGoto action_2
action_22 (6) = happyGoto action_3
action_22 (7) = happyGoto action_4
action_22 _ = happyFail

action_23 _ = happyReduce_1

happyReduce_1 = happyReduce 6 4 reduction where {
  reduction
	((HappyAbsSyn4  happy_var_6) :
	_ :
	(HappyAbsSyn4  happy_var_4) :
	_ :
	(HappyTerminal (TokenVar happy_var_2)) :
	_ :
	happyRest)
	 = HappyAbsSyn4
		 (Let happy_var_2 happy_var_4 happy_var_6) : happyRest;
  reduction _ = notHappyAtAll }

happyReduce_2 = happySpecReduce_1 4 reduction where {
  reduction
	(HappyAbsSyn5  happy_var_1)
	 =  HappyAbsSyn4
		 (Exp1 happy_var_1);
  reduction _  = notHappyAtAll }

happyReduce_3 = happySpecReduce_3 5 reduction where {
  reduction
	(HappyAbsSyn6  happy_var_3)
	_
	(HappyAbsSyn5  happy_var_1)
	 =  HappyAbsSyn5
		 (Plus happy_var_1 happy_var_3);
  reduction _ _ _  = notHappyAtAll }

happyReduce_4 = happySpecReduce_3 5 reduction where {
  reduction
	(HappyAbsSyn6  happy_var_3)
	_
	(HappyAbsSyn5  happy_var_1)
	 =  HappyAbsSyn5
		 (Minus happy_var_1 happy_var_3);
  reduction _ _ _  = notHappyAtAll }

happyReduce_5 = happySpecReduce_1 5 reduction where {
  reduction
	(HappyAbsSyn6  happy_var_1)
	 =  HappyAbsSyn5
		 (Term happy_var_1);
  reduction _  = notHappyAtAll }

happyReduce_6 = happySpecReduce_3 6 reduction where {
  reduction
	(HappyAbsSyn7  happy_var_3)
	_
	(HappyAbsSyn6  happy_var_1)
	 =  HappyAbsSyn6
		 (Times happy_var_1 happy_var_3);
  reduction _ _ _  = notHappyAtAll }

happyReduce_7 = happySpecReduce_3 6 reduction where {
  reduction
	(HappyAbsSyn7  happy_var_3)
	_
	(HappyAbsSyn6  happy_var_1)
	 =  HappyAbsSyn6
		 (Div happy_var_1 happy_var_3);
  reduction _ _ _  = notHappyAtAll }

happyReduce_8 = happySpecReduce_1 6 reduction where {
  reduction
	(HappyAbsSyn7  happy_var_1)
	 =  HappyAbsSyn6
		 (Factor happy_var_1);
  reduction _  = notHappyAtAll }

happyReduce_9 = happySpecReduce_1 7 reduction where {
  reduction
	(HappyTerminal (TokenInt happy_var_1))
	 =  HappyAbsSyn7
		 (Int happy_var_1);
  reduction _  = notHappyAtAll }

happyReduce_10 = happySpecReduce_1 7 reduction where {
  reduction
	(HappyTerminal (TokenVar happy_var_1))
	 =  HappyAbsSyn7
		 (Var happy_var_1);
  reduction _  = notHappyAtAll }

happyReduce_11 = happySpecReduce_3 7 reduction where {
  reduction
	_
	(HappyAbsSyn4  happy_var_2)
	_
	 =  HappyAbsSyn7
		 (Brack happy_var_2);
  reduction _ _ _  = notHappyAtAll }

happyNewToken action sts stk [] =
	action 19 19 (error "reading EOF!") (HappyState action) sts stk []

happyNewToken action sts stk (tk:tks) =
	let cont i = action i i tk (HappyState action) sts stk tks in
	case tk of {
	TokenLet -> cont 8;
	TokenIn -> cont 9;
	TokenInt happy_dollar_dollar -> cont 10;
	TokenVar happy_dollar_dollar -> cont 11;
	TokenEq -> cont 12;
	TokenPlus -> cont 13;
	TokenMinus -> cont 14;
	TokenTimes -> cont 15;
	TokenDiv -> cont 16;
	TokenOB -> cont 17;
	TokenCB -> cont 18;
	}

happyThen = \m k -> k m
happyReturn = \a tks -> a
calc = happyParse







happyError tks = error "Parse error"



data Exp  = Let String Exp Exp | Exp1 Exp1 
data Exp1 = Plus Exp1 Term | Minus Exp1 Term | Term Term 
data Term = Times Term Factor | Div Term Factor | Factor Factor 
data Factor = Int Int | Var String | Brack Exp 



data Token
	= TokenLet
	| TokenIn
	| TokenInt Int
	| TokenVar String
	| TokenEq
	| TokenPlus
	| TokenMinus
	| TokenTimes
	| TokenDiv
	| TokenOB
	| TokenCB



lexer :: String -> [Token]
lexer [] = []
lexer (c:cs) 
	| isSpace c = lexer cs
	| isAlpha c = lexVar (c:cs)
	| isDigit c = lexNum (c:cs)
lexer ('=':cs) = TokenEq : lexer cs
lexer ('+':cs) = TokenPlus : lexer cs
lexer ('-':cs) = TokenMinus : lexer cs
lexer ('*':cs) = TokenTimes : lexer cs
lexer ('/':cs) = TokenDiv : lexer cs
lexer ('(':cs) = TokenOB : lexer cs
lexer (')':cs) = TokenCB : lexer cs

lexNum cs = TokenInt (read num) : lexer rest
	where (num,rest) = span isDigit cs

lexVar cs =
   case span isAlpha cs of
	("let",rest) -> TokenLet : lexer rest
	("in",rest)  -> TokenIn : lexer rest
	(var,rest)   -> TokenVar var : lexer rest




runCalc :: String -> Exp
runCalc = calc . lexer



main = case runCalc "1 + 2 + 3" of {
	(Exp1 (Plus (Plus (Term (Factor (Int 1))) (Factor (Int 2))) (Factor (Int 3))))  ->
	case runCalc "1 * 2 + 3" of {
	(Exp1 (Plus (Term (Times (Factor (Int 1)) (Int 2))) (Factor (Int 3)))) ->
	case runCalc "1 + 2 * 3" of {
	(Exp1 (Plus (Term (Factor (Int 1))) (Times (Factor (Int 2)) (Int 3)))) ->
	case runCalc "let x = 2 in x * (x - 2)" of {
	(Let "x" (Exp1 (Term (Factor (Int 2)))) (Exp1 (Term (Times (Factor (Var "x")) (Brack (Exp1 (Minus (Term (Factor (Var "x"))) (Factor (Int 2))))))))) -> print "Test works\n"; 
	_ -> quit } ; _ -> quit } ; _ -> quit } ; _ -> quit }
quit = print "Test failed\n"

-- $Id: HappyTemplate,v 1.10 1999/06/30 14:14:33 simonmar Exp $

{-
	The stack is in the following order throughout the parse:

	i	current token number
	j	another copy of this to avoid messing with the stack
	tk	current token semantic value
	st	current state
	sts	state stack
	stk	semantic stack
-}

-----------------------------------------------------------------------------

happyParse = happyNewToken action_0 [] []

-- All this HappyState stuff is simply because we can't have recursive
-- types in Haskell without an intervening data structure.

newtype HappyState b c = HappyState
        (Int ->                         -- token number
         Int ->                         -- token number (yes, again)
         b ->                           -- token semantic value
         HappyState b c ->              -- current state
         [HappyState b c] ->            -- state stack
         c)

-----------------------------------------------------------------------------
-- Accepting the parse

happyAccept j tk st sts [ HappyAbsSyn4 ans ] = happyReturn ans
happyAccept j tk st sts _                    = notHappyAtAll

-----------------------------------------------------------------------------
-- Shifting a token

happyShift new_state 1 tk st sts stk@(HappyErrorToken i : _) =
--     _trace "shifting the error token" $
     new_state i i tk (HappyState new_state) (st:sts) stk

happyShift new_state i tk st sts stk =
     happyNewToken new_state (st:sts) (HappyTerminal tk:stk)

-----------------------------------------------------------------------------
-- Reducing

-- happyReduce is specialised for the common cases.

-- don't allow reductions when we're in error recovery, because this can
-- lead to an infinite loop.

happySpecReduce_0 i fn 1 tk st sts stk
     = happyFail 1 tk st sts stk 
happySpecReduce_0 i fn j tk st@(HappyState action) sts stk
     = action i j tk st (st:sts) (fn : stk)

happySpecReduce_1 i fn 1 tk st sts stk
     = happyFail 1 tk st sts stk 
happySpecReduce_1 i fn j tk _ sts@(st@(HappyState action):_) (v1:stk')
     = action i j tk st sts (fn v1 : stk')
happySpecReduce_1 _ _ _ _ _ _ _
     = notHappyAtAll

happySpecReduce_2 i fn 1 tk st sts stk
     = happyFail 1 tk st sts stk 
happySpecReduce_2 i fn j tk _ (_:sts@(st@(HappyState action):_)) (v1:v2:stk')
     = action i j tk st sts (fn v1 v2 : stk')
happySpecReduce_2 _ _ _ _ _ _ _
     = notHappyAtAll

happySpecReduce_3 i fn 1 tk st sts stk
     = happyFail 1 tk st sts stk 
happySpecReduce_3 i fn j tk _ (_:_:sts@(st@(HappyState action):_)) 
	(v1:v2:v3:stk')
     = action i j tk st sts (fn v1 v2 v3 : stk')
happySpecReduce_3 _ _ _ _ _ _ _
     = notHappyAtAll

happyReduce k i fn 1 tk st sts stk
     = happyFail 1 tk st sts stk 
happyReduce k i fn j tk st sts stk = action i j tk st' sts' (fn stk)
       where sts'@(st'@(HappyState action):_) = drop (k::Int) (st:sts)

happyMonadReduce k i c fn 1 tk st sts stk
     = happyFail 1 tk st sts stk 
happyMonadReduce k i c fn j tk st sts stk =
	happyThen (fn stk) (\r -> action i j tk st' sts' (c r : stk'))
       where sts'@(st'@(HappyState action):_) = drop (k::Int) (st:sts)
	     stk' = drop (k::Int) stk

-----------------------------------------------------------------------------
-- Moving to a new state after a reduction

happyGoto action j tk st = action j j tk (HappyState action)

-----------------------------------------------------------------------------
-- Error recovery (1 is the error token)

-- fail if we are in recovery and no more states to discard
happyFail  1 tk st' [] stk = 
--	trace "failing" $ 
    	happyError

-- discard a state
happyFail  1 tk st' (st@(HappyState action):sts) (saved_tok : _ : stk) =
--	trace ("discarding state, depth " ++ show (length stk))  $
	action 1 1 tk st sts (saved_tok:stk)

-- Enter error recovery: generate an error token,
-- 			 save the old token and carry on.

-- we push the error token on the stack in anticipation of a shift,
-- and also because this is a convenient place to store the saved token.

happyFail  i tk st@(HappyState action) sts stk =
--	_trace "entering error recovery" $
	action 1 1 tk st sts (HappyErrorToken i : stk)

-- Internal happy errors:

notHappyAtAll = error "Internal Happy error\n"

-----------------------------------------------------------------------------
-- Don't inline any functions from the template.  GHC has a nasty habit
-- of deciding to inline happyGoto everywhere, which increases the size of
-- the generated parser quite a bit.

{-# NOINLINE happyShift #-}
{-# NOINLINE happySpecReduce_0 #-}
{-# NOINLINE happySpecReduce_1 #-}
{-# NOINLINE happySpecReduce_2 #-}
{-# NOINLINE happySpecReduce_3 #-}
{-# NOINLINE happyReduce #-}
{-# NOINLINE happyMonadReduce #-}
{-# NOINLINE happyGoto #-}
{-# NOINLINE happyFail #-}

-- end of Happy Template.
