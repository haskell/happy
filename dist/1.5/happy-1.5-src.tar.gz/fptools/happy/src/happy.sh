# Mini-driver for Happy

# needs the following variables:
#	HAPPYLIB
#	HAPPYBIN

$HAPPYBIN --template $HAPPYLIB $*
