module Version (version) where

version = "1.5"
