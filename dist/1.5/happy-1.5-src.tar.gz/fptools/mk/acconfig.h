/* Leave this blank line here -- autoheader needs it! */


/* Define this if your time.h defines altzone */
#undef HAVE_ALTZONE

/* Define as the type of timezone.  */
#undef TYPE_TIMEZONE

