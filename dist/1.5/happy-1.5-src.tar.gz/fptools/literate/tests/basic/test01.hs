{-# LINE 13 "test01.lhs" -}
 b = a+3
 a = b+3

