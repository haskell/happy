f x y = y
g x y = x
>  z f a b = a b
>  y b f a = f a
>  x a b f = b f
main _ = [AppendChan "stdout" "Hello, world!\n"]
f x y = y
g x y = x
